# PHP-Heroku-PostgreSQL
This is the project I used as shown in video.
Add ROOT_URL in the config/config.php.
ROOT_URL is the website base url.
Add Database credentials in the config/db.php.
